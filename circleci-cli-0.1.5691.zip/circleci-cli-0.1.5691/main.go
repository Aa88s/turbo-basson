package main

import (
	"github.com/CircleCI-Public/circleci-cli/cmd"
)

func main() {
	// See cmd/root.go for Execute()
	cmd.Execute()
}
