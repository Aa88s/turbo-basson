# Contributing to the Atom Flight Manual

Contributing is easy. Download the manual, make a change to the Asciidoc (or whatever you want to change), fork this repository, push it to a branch and send us a Pull Request.

If you're not sure about the change or the idea for the change, open an issue first to see if it's something we'll want to pull in.
